<?php
// Rename this file as config.php and fill in the details below.
$conf = array();
$conf["apiurl"] = ""; // L'adreça de l'API del graf original.
$conf["password"] = ""; // La contrasenya perquè la gent pugui entrar al graf.

